# Deployment checklist

- [ ] Extract ZIP and open repository folder.
- [ ] Run frontend and backend locally.
- [ ] Test `/health` and `/docs`.
- [ ] Test project planning with and without an AI key.
- [ ] Add Gemini key only to backend environment if using AI features.
- [ ] Create empty GitHub repository and push source.
- [ ] Deploy backend and test its public `/health` endpoint.
- [ ] Set backend `FRONTEND_ORIGINS` to exact Vercel origin.
- [ ] Deploy frontend with `VITE_API_URL` set to backend base URL.
- [ ] Test image upload, assistant, planner, and valuation on public site.
- [ ] Paste actual GitHub and demo URLs into Skillwallet.
- [ ] Never share or commit API keys.
