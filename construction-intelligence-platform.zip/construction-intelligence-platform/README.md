# BuildSense — Multimodal Construction Intelligence Platform

A full-stack starter project for construction decision support, with a React/Vite dashboard and FastAPI backend. Includes preliminary image-based site safety review, visible crack assessment, an AI construction assistant, a rule-based/AI-assisted project planner, and an indicative property valuation calculator.

> **Responsible use:** This is a demonstration and decision-support tool. AI image outputs and schedules are not certified inspections or engineering advice. A qualified professional must verify safety, structural damage, code compliance, valuation, and construction plans.

## Features

- Responsive dashboard and navigation
- Site safety image analysis endpoint (`POST /api/analyze/safety`)
- Visible crack assessment endpoint (`POST /api/analyze/cracks`)
- AI construction assistant (`POST /api/assistant`)
- Project plan generator (`POST /api/plan`), with a deterministic starter plan if no AI key is set
- Instant indicative property valuation calculator in the frontend
- API health/status endpoints and interactive FastAPI docs
- Environment-based configuration; secrets are not stored in source code

## Requirements

- Node.js LTS and npm
- Python 3.10+ (Render config uses Python 3.12)
- Optional: Gemini API key from Google AI Studio to enable AI-generated answers and image analysis

## Run locally (Windows PowerShell)

Open two terminals in VS Code.

### 1. Backend

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
# Optional: set an API key for this terminal session
$env:GEMINI_API_KEY="YOUR_KEY_HERE"
uvicorn main:app --reload --port 8000
```

Backend docs: http://127.0.0.1:8000/docs  
Health check: http://127.0.0.1:8000/health

On macOS/Linux, create/activate the virtual environment with `python3 -m venv .venv` and `source .venv/bin/activate`.

### 2. Frontend

```powershell
cd frontend
npm install
npm run dev
```

Open the URL Vite prints (normally http://localhost:5173).

If the backend is hosted somewhere other than localhost, create `frontend/.env` with:

```env
VITE_API_URL=https://YOUR-BACKEND-URL
```

Do not put your Gemini key in any `VITE_` variable: Vite variables are exposed to browser code.

## Configure Gemini

1. Get an API key from https://aistudio.google.com/ if available to your account and region.
2. Set `GEMINI_API_KEY` as a backend environment variable in your shell or hosting provider. Never commit a real key.
3. The default model is `gemini-2.5-flash`; set `GEMINI_MODEL` to another currently available model if needed.
4. Restart/redeploy the backend after changing environment variables.

Without a key, the assistant/image analysis explains that AI is not configured; the project planner still returns a rule-based draft. This is intentional rather than pretending an AI inference occurred.

## Deploy backend on Render

1. Push this folder to a GitHub repository.
2. In Render, create a new Blueprint and select this repository; `render.yaml` defines the API service.
3. Add `GEMINI_API_KEY` in the Render service environment settings (optional for non-AI demo mode).
4. After deployment, copy the service URL and test `/health` and `/docs`.
5. Update `FRONTEND_ORIGINS` in Render to your exact deployed frontend origin, e.g. `https://your-project.vercel.app` (comma-separated origins are supported). Redeploy.

## Deploy frontend on Vercel

1. Import the GitHub repository in Vercel.
2. Set **Root Directory** to `frontend`.
3. Add environment variable `VITE_API_URL` with your deployed backend base URL, e.g. `https://your-api.onrender.com` (no trailing slash required).
4. Deploy and open the public URL. Make sure `FRONTEND_ORIGINS` on the backend includes the exact Vercel origin, then redeploy the backend if changed.

## Upload to GitHub

1. Create a new empty repository at https://github.com/new. Do not add a README if you plan to push this README.
2. Extract this project ZIP, open a terminal in the extracted `construction-intelligence-platform` folder, then run:

```bash
git init
git add .
git commit -m "Build construction intelligence platform"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with the URL GitHub shows for your repository. Do not upload `.env` files, API keys, passwords, or private project data.

## Skillwallet links

- **GitHub Link:** your repository URL after pushing successfully.
- **Demo Link:** your Vercel public deployment URL after deploying successfully.

Do not submit placeholder URLs. Test the deployed site and the API before sharing links with your mentor.

## Known limitations / next steps

- No database or user authentication is included in this initial submission-ready prototype.
- Property valuation is a simplified illustrative calculation, not a market model or appraisal.
- The AI provider may be unavailable, rate-limited, or return incorrect results; handle failures and verify outputs.
- Add tests, persistent reports, authentication, rate limits, privacy controls, and proper production monitoring before real-world use.
