import base64
import json
import os
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

APP_NAME = "Multimodal Construction Intelligence Platform"
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()

app = FastAPI(title=APP_NAME, version="1.0.0", description="Construction decision-support API")

raw_origins = os.getenv("FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
origins = [origin.strip() for origin in raw_origins.split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)

class AssistantRequest(BaseModel):
    message: str = Field(min_length=1, max_length=6000)

class PlanRequest(BaseModel):
    name: str = Field(default="Construction project", max_length=180)
    duration_days: int = Field(default=90, ge=1, le=3650)
    budget_inr: float = Field(default=4500000, ge=0)
    team_size: int = Field(default=8, ge=1, le=10000)
    scope: str = Field(default="General construction works", max_length=6000)

class Task(BaseModel):
    name: str
    description: str
    duration_days: int

class PlanResponse(BaseModel):
    title: str
    summary: str
    tasks: list[Task]
    disclaimer: str


def gemini_client():
    if not GEMINI_API_KEY:
        return None
    try:
        from google import genai
        return genai.Client(api_key=GEMINI_API_KEY)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"AI client could not initialize: {exc}") from exc


def generate_text(prompt: str) -> str | None:
    client = gemini_client()
    if client is None:
        return None
    try:
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        text = getattr(response, "text", None)
        return text.strip() if text else "The AI provider returned an empty response. Please try again."
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI provider request failed. Check API key, model availability, quota, and network. Details: {exc}") from exc

@app.get("/")
def root():
    return {"name": APP_NAME, "status": "running", "docs": "/docs", "ai_configured": bool(GEMINI_API_KEY)}

@app.get("/health")
def health():
    return {"status": "healthy", "ai_configured": bool(GEMINI_API_KEY)}

@app.get("/api/status")
def status():
    return {"service": APP_NAME, "version": "1.0.0", "ai_configured": bool(GEMINI_API_KEY), "model": GEMINI_MODEL if GEMINI_API_KEY else None}

@app.post("/api/analyze/{kind}")
async def analyze_image(kind: str, file: UploadFile = File(...)):
    if kind not in {"safety", "cracks"}:
        raise HTTPException(status_code=404, detail="Unknown analysis type. Use 'safety' or 'cracks'.")
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail="Please upload a valid image file.")
    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="The uploaded image is empty.")
    if len(contents) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image exceeds the 10 MB upload limit.")
    try:
        from PIL import Image
        import io
        image = Image.open(io.BytesIO(contents))
        image.verify()
    except Exception as exc:
        raise HTTPException(status_code=415, detail="The file could not be read as a supported image.") from exc

    if not GEMINI_API_KEY:
        return {
            "mode": "configuration_required",
            "analysis_type": kind,
            "filename": file.filename,
            "analysis": "AI analysis is not configured yet. Add GEMINI_API_KEY to the backend environment and restart the API. No image-based conclusion has been generated. For a real inspection, have a qualified site professional review the image.",
            "findings": [],
            "disclaimer": "No AI inference was performed because the provider key is missing."
        }
    prompt = (
        "You are a cautious construction decision-support assistant. Analyze the supplied construction image only for visible evidence. "
        "Do not infer hidden conditions or claim certainty. State image limitations, uncertainty, and actionable next steps. "
        "Do not present the output as a certified engineering, safety, or compliance inspection.\n"
    )
    if kind == "safety":
        prompt += "Task: preliminary visual site safety review. Identify only visible potential hazards, PPE observations if clearly visible, housekeeping/access concerns, and practical items for an on-site professional to verify. Do not assert a person lacks PPE unless visible evidence supports it."
    else:
        prompt += "Task: preliminary visible concrete/masonry crack review. Describe visible crack location/pattern/appearance, uncertainty, documentation suggestions, and when to escalate to a qualified structural engineer. Never infer structural integrity or classify severity definitively from a photo alone."
    try:
        from google.genai import types
        client = gemini_client()
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=[types.Part.from_bytes(data=contents, mime_type=file.content_type), prompt],
        )
        result = (getattr(response, "text", None) or "The AI provider returned an empty response.").strip()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI image analysis failed. Check API key, model availability, quota, and image format. Details: {exc}") from exc
    return {"mode": "ai", "analysis_type": kind, "filename": file.filename, "analysis": result, "disclaimer": "AI-generated preliminary observations only; verify with qualified professionals."}

@app.post("/api/assistant")
def assistant(body: AssistantRequest):
    prompt = (
        "You are BuildSense, a cautious construction project support assistant. Answer clearly and practically. "
        "For safety-critical, structural, legal, code-compliance, or financial decisions, explain that qualified local professionals must verify. "
        "Do not invent local regulations or exact prices. If information is missing, state assumptions.\n\nUser question: " + body.message
    )
    result = generate_text(prompt)
    if result is None:
        return {"mode": "configuration_required", "answer": "The AI assistant is ready, but a provider API key is not configured. Set GEMINI_API_KEY in the backend environment to enable generated answers. Until then, use this workspace for the valuation calculator and draft planning workflow. Verify safety-critical decisions with qualified professionals."}
    return {"mode": "ai", "answer": result}

@app.post("/api/plan", response_model=PlanResponse)
def plan_project(body: PlanRequest):
    prompt = (
        "Create a preliminary construction project plan as valid JSON only, with keys title, summary, tasks. "
        "tasks must be an array of objects with name, description, duration_days (integer). Include logical dependencies, "
        "site setup, approvals/permits as applicable, procurement, construction work packages, QA/QC, inspections, handover. "
        "Respect the total duration and scope but state it is indicative. Do not present invented legal requirements as facts. "
        f"Project: {body.name}\nDuration days: {body.duration_days}\nBudget INR: {body.budget_inr}\nTeam size: {body.team_size}\nScope: {body.scope}\n"
    )
    result = generate_text(prompt)
    if result:
        try:
            cleaned = result.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.split("\n", 1)[1].rsplit("```", 1)[0].strip()
            data: dict[str, Any] = json.loads(cleaned)
            tasks = data.get("tasks", [])
            if not isinstance(tasks, list):
                raise ValueError("tasks must be an array")
            safe_tasks = []
            for task in tasks[:30]:
                if not isinstance(task, dict):
                    continue
                safe_tasks.append(Task(name=str(task.get("name", "Work package"))[:180], description=str(task.get("description", ""))[:1000], duration_days=max(1, min(body.duration_days, int(task.get("duration_days", 1))))))
            if not safe_tasks:
                raise ValueError("No tasks returned")
            return PlanResponse(title=str(data.get("title", body.name))[:180], summary=str(data.get("summary", "Indicative draft plan"))[:2000], tasks=safe_tasks, disclaimer="Draft planning aid only. Validate sequencing, permits, site conditions, budget, and durations with the responsible project team.")
        except Exception:
            # Fall through to deterministic draft when model output isn't valid JSON.
            pass
    # Useful deterministic baseline, including when no AI key is configured.
    phases = [
        ("Pre-construction and site setup", "Confirm scope, site access, required approvals, survey, safety plan and logistics.", .10),
        ("Design coordination and procurement", "Coordinate drawings and specifications; schedule materials, subcontractors and equipment.", .15),
        ("Foundation and substructure", "Complete set-out, excavation, foundation works and required inspections according to approved drawings.", .20),
        ("Structure and building envelope", "Execute structural works and coordinate masonry, roofing and weatherproofing.", .25),
        ("MEP and internal works", "Coordinate electrical, plumbing and other services with finishing work and inspections.", .18),
        ("Quality checks and handover", "Resolve defects, complete testing and documentation, and prepare handover records.", .12),
    ]
    tasks = [Task(name=n, description=d, duration_days=max(1, round(body.duration_days * share))) for n, d, share in phases]
    return PlanResponse(title=body.name, summary=f"Indicative {body.duration_days}-day draft for a team of {body.team_size}. Budget entered: ₹{body.budget_inr:,.0f}. {('AI is not configured; this is a rule-based starter plan.' if not GEMINI_API_KEY else 'AI response could not be parsed; this is a rule-based starter plan.')}", tasks=tasks, disclaimer="Draft planning aid only. Durations are illustrative, may not sum exactly to the project duration, and must be validated against drawings, site conditions, procurement lead times, local requirements, and the responsible project team.")
